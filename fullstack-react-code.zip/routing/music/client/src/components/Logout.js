import React, { Component } from 'react';

import { client } from '../Client';

class Logout extends Component {

}

export default Logout;
