import React from 'react'

const Header = function(props) {
  return (<h1>{props.headerText}</h1>)
}

export default Header
