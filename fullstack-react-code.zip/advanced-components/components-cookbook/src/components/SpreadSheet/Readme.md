## Spreadsheet

    const data = require('./data.js')(300);
    <SpreadSheet data={data} />
    
The `SpreadSheet` component.
